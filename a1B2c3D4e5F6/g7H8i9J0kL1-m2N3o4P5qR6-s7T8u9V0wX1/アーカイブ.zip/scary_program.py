import tkinter as tk
import time

def scare():
    # 初期ウィンドウの設定
    root = tk.Tk()
    root.attributes("-fullscreen", True)  # フルスクリーン
    root.config(bg="white")  # 初期背景色

    # 10秒間反転した背景
    for _ in range(10):  # 10回色を反転
        root.config(bg="black" if root.cget("bg") == "white" else "white")
        root.update()
        time.sleep(1)  # 1秒間隔で反転

    # 警告メッセージを表示
    warning_label = tk.Label(root, text="注意: 終わらない処理が発生しています！", bg=root.cget("bg"), fg="red", font=("Arial", 40))
    warning_label.pack(expand=True)

    root.mainloop()

if __name__ == "__main__":
    scare()