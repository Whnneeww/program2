import os
import time
import ctypes
import winreg
import random
import numpy as np
from PIL import Image
from win32com.client import Dispatch

def get_current_wallpaper_path():
    # Windowsレジストリから壁紙のパスを取得する
    reg_path = r"Control Panel\Desktop"
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path) as key:
        wallpaper_path, _ = winreg.QueryValueEx(key, "WallPaper")
    return wallpaper_path

def set_wallpaper(image_path):
    # Windowsの壁紙を設定する
    ctypes.windll.user32.SystemParametersInfoW(20, 0, image_path, 3)

def distort_image(image_path):
    img = Image.open(image_path)
    width, height = img.size
    data = np.array(img)
    distorted_data = np.zeros_like(data)

    for y in range(height):
        for x in range(width):
            new_x = (x + random.randint(-10, 10)) % width
            new_y = (y + random.randint(-10, 10)) % height
            distorted_data[y, x] = data[new_y, new_x]

    distorted_img = Image.fromarray(distorted_data)
    distorted_img_path = "distorted_background.png"
    distorted_img.save(distorted_img_path)
    set_wallpaper(os.path.abspath(distorted_img_path))

def change_icons(new_icon_path):
    desktop_path = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
    shell = Dispatch('WScript.Shell')

    for item in os.listdir(desktop_path):
        if item.endswith('.lnk'):
            shortcut = shell.CreateShortCut(os.path.join(desktop_path, item))
            shortcut.IconLocation = new_icon_path
            shortcut.save()

def restore_icons(original_icons):
    desktop_path = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
    shell = Dispatch('WScript.Shell')

    for item in os.listdir(desktop_path):
        if item.endswith('.lnk'):
            shortcut = shell.CreateShortCut(os.path.join(desktop_path, item))
            shortcut.IconLocation = original_icons[item]
            shortcut.save()

def change_wallpaper_temporarily():
    original_wallpaper = get_current_wallpaper_path()  # 元の壁紙を取得
    weird_wallpapers = [
        os.path.expanduser("C:\\path\\to\\your\\image1.png"),
        os.path.expanduser("C:\\path\\to\\your\\image2.png"),
    ]

    for _ in range(5):
        new_wallpaper = random.choice(weird_wallpapers)
        set_wallpaper(new_wallpaper)
        time.sleep(1)

    set_wallpaper(original_wallpaper)  # 元の壁紙に戻す

def create_task(task_name, script_path):
    scheduler = Dispatch('Schedule.Service')
    scheduler.Connect()

    # 新しいタスクを作成
    new_task = scheduler.NewTask(0)
    new_task.RegistrationInfo.Description = 'A scary task to run after restart'

    # トリガー設定: 再起動時に実行
    trigger = new_task.Triggers.Create(4)  # 4は再起動時
    trigger.Delay = 'PT0S'  # 何の遅延もなし

    # アクション設定: スクリプトを実行
    exec_action = new_task.Actions.Create(0)  # 0はExecアクション
    exec_action.Path = script_path  # 絶対パスを指定

    # タスクを登録
    scheduler.GetFolder('\\').RegisterTaskDefinition(
        task_name,
        new_task,
        6,  # 6は再登録
        None,  # ユーザーは指定しない
        None,  # パスワードは指定しない
        3,  # 3はユーザーの権限で実行
        None,  # 認証情報は指定しない
        None  # ワーキングディレクトリを指定しない
    )
    print(f'Task "{task_name}" created successfully!')

if __name__ == "__main__":
    # 新しいアイコンのパス（実際のアイコンファイルに置き換えてください）
    new_icon_path = os.path.abspath("new_icon.ico")

    # デスクトップのアイコンの元の設定を保存
    original_icons = {}
    desktop_path = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
    shell = Dispatch('WScript.Shell')

    for item in os.listdir(desktop_path):
        if item.endswith('.lnk'):
            shortcut = shell.CreateShortCut(os.path.join(desktop_path, item))
            original_icons[item] = shortcut.IconLocation

    # アイコンを3回変更して戻す
    for _ in range(3):
        change_icons(new_icon_path)
        time.sleep(2)
        restore_icons(original_icons)
        time.sleep(2)

    # 背景を一時的に変更
    change_wallpaper_temporarily()

    # スクリプトのパスを指定
    script_path = os.path.abspath('scary_program.py')
    create_task("ScaryTask", script_path)